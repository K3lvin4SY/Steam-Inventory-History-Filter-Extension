document.getElementById("sp").addEventListener("click", function(event) {
  window.open("https://steamcommunity.com/id/K3B04", '_blank');
});

document.getElementById("to").addEventListener("click", function(event) {
  window.open("https://steamcommunity.com/tradeoffer/new/?partner=328057212&token=1iZrkZSt", '_blank');
});

document.getElementById("pp").addEventListener("click", function(event) {
  window.open("https://paypal.me/KelvinBrahe", '_blank');
});

document.getElementById("invHisPage").addEventListener("click", function(event) {
  window.open("https://steamcommunity.com/id/user/inventoryhistory/", '_blank');
});